import {pool, testConnection} from './db.ts'

await testConnection();

async function createStudentTable() {
    const sql =`
        CREATE TABLE IF NOT EXISTS student(
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(10) NOT NULL
        );
    `
    try{
        await pool.query(sql);
        console.log("user table created successfully");
    }catch(error){
        console.error("error is here --->", error)
    }finally{
        await pool.end();
    }
}

async function insertData(name: string) {
    const sql = `INSERT INTO student (name) VALUE (?)`;
    try{
        await pool.query(sql, [name])
        console.log("user table created successfully");
    }catch(error){
        console.error("error is here --->", error)
    }finally{
        await pool.end();
    }
}

async function getData(){
    const sql= `select * from student`;
    const data = await pool.query(sql);
    console.log(data)
}

async function updateData(name:string, id: number) {
    const sql = `update student set name = ? where id = ?`;
    await pool.query(sql,[name,id])
}

async function deleteData(id: number) {
    const sql = `delete from student where id = ?`
    await pool.query(sql,[id]);
}
export {createStudentTable, insertData, getData, updateData, deleteData};
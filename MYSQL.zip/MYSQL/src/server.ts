import {createStudentTable, insertData, getData,updateData, deleteData} from  './query.ts'
await getData();
await deleteData(1);
getData();
import sql from 'mysql2/promise'
import dotenv from 'dotenv'

dotenv.config();

const DB_user=process.env.SQL_USER;
const DB_pass=process.env.SQL_PASS;
const DB_host=process.env.SQL_HOST;
const DB_port=Number(process.env.SQL_PORT);
const DB_database=process.env.SQL_DB;

if(!DB_user || !DB_pass || !DB_host || !DB_host || !DB_database || !DB_port) throw new Error("Missing database credentials in .env");

const pool = sql.createPool({
    user: DB_user,
    password: DB_pass,
    host: DB_host,
    port: DB_port,
    database: DB_database
})

async function testConnection() {
    try{
        const getConnection = await pool.getConnection();
            console.log("Connection Found...")
            getConnection.release();
            
    }
    catch(error) {
        console.error(error)
        process.exit(1)
    }
    
}

process.on("SIGINT", () => {
  console.log("Caught SIGINT, cleaning up...");
  // Close DB connections or other resources
  process.exit(0);
});


export {pool,testConnection};